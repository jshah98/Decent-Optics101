import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Intro extends JPanel
{
  public static void main (String[]args)
  {
    JFrame test= new JFrame();
    Intro splash= new Intro();
    JLabel imageLabel= new JLabel();
    ImageIcon pic= new ImageIcon("FINAL3.gif");
    imageLabel.setIcon(pic);
    splash.add(imageLabel);
    splash.setLayout(new FlowLayout(0));
    splash.setSize(585,585);
    test.add(splash);
    test.setVisible(true);
    test.setSize(600,600);
    test.setBackground(Color.BLACK);
    try
    {
      Thread.sleep(1300);
    }
    catch(Exception e){}
    pic= new ImageIcon("backgroundFinal.jpg");
    imageLabel.setIcon(pic);  
    test.dispose();
    //new IntroTest();
  }
  public Intro()
  {
    this.setOpaque(true);
    this.setBackground(Color.BLACK); 
  }
}